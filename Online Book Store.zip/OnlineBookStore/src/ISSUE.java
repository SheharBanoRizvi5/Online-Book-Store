
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author BOSS
 */
public class ISSUE extends javax.swing.JFrame {

    /**
     * Creates new form ISSUE
     */Entry[] hashArray; // array holds hash table
        int size=100; 
        int count=0;
        String bn;
        String an;
        int pri=1350;
        
         String currentTime;
         String currentDate;
        
    public ISSUE() {
        initComponents();
        hashArray = new Entry[size];
    }
        
        public boolean isFull()
    {
        return count==size;
        
    }
        int hashFunc( String theKey ) // convert the string into a numeric key
{
    int hashVal=0;
// convert the string into a numeric key
    for(int i = 0; i < theKey.length(); i++)
    hashVal = 37*hashVal + (int)theKey.charAt(i);
    hashVal = hashVal % size;
    
    if(hashVal < 0 )
    hashVal = hashVal + size;
    return hashVal;
}
       public void insert(String theKey, String auth)
    {// insert a record {
      
if( !isFull() )
{
    
int hashVal = hashFunc(theKey); // hash the key
// until empty cell or null,
while(hashArray[hashVal] != null )
{
++hashVal;

// go to next cell
hashVal%=size; // wraparound if necessary
}
hashArray[hashVal] = new Entry(theKey, auth);
count++; // update count
}
    else
System.out.println("Table is Full");// yahan pr jesy hm ny insertion from file krwaya tha na us trhan jb tm filling krogi na or data ko store krwaogi tou phir us trhan call dy dogi yahan pr insertion from file ky functionko
    
} 
          Entry search(String theKey){
              bn=titlename.getText();
//              auth=authorname.getText();
        int hvale=hashFunc(theKey);
        while(hashArray[hvale]!=null){
            if(hashArray[hvale].bn==theKey)
            
                 return hashArray[hvale];
            
            
        ++hvale;
        hvale%=size;
        }
        return null;
    }
public void insertionfromfile(){
           String tn , aun ;
           
           try{
               FileReader fr=new FileReader("Record.txt");
               BufferedReader br=new BufferedReader(fr); 
               int i=0;
              String line;
           while((line=br.readLine()) !=null)
           {
               tn=line.split("\t")[0];                
               aun=line.split("\t")[1];
               insert(tn,aun);
               Entry item = search(tn);
               if(item!=null){
                   System.out.println("Book found "+item.bn+"\n"+item.an+"\n");
        }
        else 
            System.out.println("Not found");
               
                          }i++;
           }catch(Exception exp){
               System.out.println("cannot open file");
           }
       }     
       public void Filing(String bn, String an, int pri){
          try{
              bn=titlename.getText();
              an=authorname.getText();
              FileWriter fw=new FileWriter("Record.txt",true);
              SimpleDateFormat f=new SimpleDateFormat("dd/MM/yyyy"+"\t\t\t"+"HH:mm:ss");
              Date date=new Date();
              System.out.println(f.format(date));
              System.out.println("Title name : " +bn+" \n Author name : "+an);
              currentDate=f.format(date);
              fw.write(bn+"\t"+an+"\t"+pri+"\t"+currentDate+"\r\n");
              fw.close();
              
          }
          catch(Exception e){
              System.out.println(" file cannnot be open");
          }
          
      }
       
      
          public void updateReserve(String tilename,String aorname){
        Mainpage m = new Mainpage();
        String usernamefile=m.retrieveCurrentUser();
     
         try{
             FileWriter fw=new FileWriter(usernamefile+"\\issued.txt",true);
             SimpleDateFormat f=new SimpleDateFormat("dd/MM/yyyy"+"\t"+"HH:mm:ss");
              Date date=new Date();
              System.out.println(f.format(date));
              currentDate=f.format(date);
              
              fw.write(currentDate+"\t"+tilename+"\t"+aorname+"\r\n");
              
             
              fw.close();
          }
          catch(Exception e){
              System.out.println(" file cannnot be open");
          }
          }
       
//    HashTables h = new HashTables(19);
//    
//    public void insertion(){
//        h.insert("Data Structures and Algorithms", "Robert Lafore", 4000);
//        h.insert("Data Structures and Algorithms", "Robert Lafore", 7000);
//    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        titlename = new javax.swing.JTextField();
        authorname = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        issue = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 151, 23));

        jPanel2.setBackground(new java.awt.Color(153, 0, 0));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image.jpg"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("ONLINE BOOK STORE");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("SEARCH BY BOOK TITLE");

        jLabel4.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("SEARCH BY AUTHOR NAME");

        issue.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        issue.setForeground(new java.awt.Color(255, 0, 0));
        issue.setText("ISSUE");
        issue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                issueActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel4)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(titlename, javax.swing.GroupLayout.PREFERRED_SIZE, 534, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(authorname))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(issue, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(80, 80, 80))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(titlename, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE))
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(authorname, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(60, 60, 60)
                .addComponent(issue, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void issueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_issueActionPerformed
        // TODO add your handling code here:
        insertionfromfile();
        String tin = titlename.getText() ,ain = authorname.getText();
        updateReserve(tin,ain);
        try{
           bn=titlename.getText();
        an=authorname.getText();
            FileWriter fw=new FileWriter("Record.txt",true);
              
              fw.write(bn+"\t"+an+"\t"+pri+"\r\n");
              Filing(bn,an,pri);
              fw.close();
              
            
        }catch(Exception exp){
         
            System.out.println(" file cannnot be open");
        }
        
        
//        bn=titlename.getText();
//        an=authorname.getText();
//        Entry item = search(bn);
//        if(item!=null)
//        {
//            System.out.println("found : "+item.key_bookName+"\t"+item.authorName);
//        }
//        else
//            System.out.println("Sorry....Not found "); 
        JOptionPane.showMessageDialog(null,"Successfully issued. \n Title Name : "+bn+"\n Author Name : "+an+"\n Price : "+pri);
        ISSUE i= new ISSUE();
        new BILL().setVisible(true);
        i.dispose();
    }//GEN-LAST:event_issueActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ISSUE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ISSUE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ISSUE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ISSUE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        
       
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ISSUE().setVisible(true);
            }
        });
    }
 
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField authorname;
    private javax.swing.JButton issue;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField titlename;
    // End of variables declaration//GEN-END:variables
}

class Entry
{
 String bn; //book name
 String an;
// int price; 

    public Entry(String key_bookName, String authorName) {
        this.bn = key_bookName;
        this.an = authorName;
//        this.price = price;
    }
}
